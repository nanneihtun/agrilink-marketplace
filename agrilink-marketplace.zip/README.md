
  # AgriLink_Mock_Up_R1 (backup)

  This is a code bundle for AgriLink_Mock_Up_R1 (backup). The original project is available at https://www.figma.com/design/Aaa6KQyv7qs3EGfS9CGQb1/AgriLink_Mock_Up_R1--backup-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  